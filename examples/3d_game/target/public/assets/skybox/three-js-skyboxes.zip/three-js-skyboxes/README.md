# Three.js Skyboxes

A Pen created on CodePen.

Original URL: [https://codepen.io/codypearce/pen/oNXQyOb](https://codepen.io/codypearce/pen/oNXQyOb).

This pen shows how to create skyboxes in Three.js. Checkout the article on how these are made, https://codinhood.com/post/create-skybox-with-threejs